# &#128007; K-Digital-Web 프로젝트
**영화 소개 및 평점 부여 사이트 제작**

- **부트스트랩 템플릿**
https://startbootstrap.com/previews/modern-business <br>
- **Django 환경 셋팅**
https://goni99developer.tistory.com/3 <br>
- **Django 웹 생성**
https://goni99developer.tistory.com/4 <br>
- **Django ORM 적용**
https://goni99developer.tistory.com/5 <br>
- **PythonAnywhere 적용**
https://goni99developer.tistory.com/6 <br>
